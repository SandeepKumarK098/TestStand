﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using NationalInstruments.TestStand.Interop.API;
using System.Security.Permissions;
using System.Runtime.Remoting.Lifetime;

namespace ShareObjectBetweenAppDomains
{
    public class ObjectToShare : MarshalByRefObject
    {
        //Constructor for our object
        public ObjectToShare(SequenceContext sc)
        {
            //Pre-TestStand 2010, the object reference must be set in the
            //.NET constructor like this, otherwise you will not be able to
            //access the object reference from another module using GetValInterface().
            //After TestStand 2010, this line is not necessary, because the .NET adapter
            //stores the object reference in a way that it can be accessed externally
            //using GetValInterface()
            sc.Locals.SetValInterface("SharedObject", 1, this);
        }

        [SecurityPermissionAttribute(SecurityAction.Demand, Flags = SecurityPermissionFlag.Infrastructure)]
        public override object InitializeLifetimeService()
        {
            // Normally MarshalByRefObject objects are cleaned up after a timeout if they
            // haven't been called recently. In order to give our objects unlimited lifetime,
            // we set the InitialLeaseTime to TimeSpan.Zero. Here's the relevent info from the
            // MSDN documentation for ILease:
            // "If the InitialLeaseTime property is set to TimeSpan.Zero, then the lease will never time out
            // and the object associated with it will have an infinite lifetime."
            ILease lease = base.InitializeLifetimeService() as ILease;
            if (lease.CurrentState == LeaseState.Initial)
            {
                lease.InitialLeaseTime = TimeSpan.Zero;
            }

            return lease;
        }

        //A simple method used to verify that we can successfully call a method of this object
        public void MyMethodCall()
        {
            MessageBox.Show("I'm able to call my object's method");
        }

    }
}
