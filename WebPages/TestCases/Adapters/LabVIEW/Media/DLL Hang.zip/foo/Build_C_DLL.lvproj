<?xml version='1.0'?>
<Project Type="Project" LVVersion="8508002">
   <Item Name="My Computer" Type="My Computer">
      <Property Name="CCSymbols" Type="Str">OS,Win;CPU,x86;</Property>
      <Property Name="server.app.propertiesEnabled" Type="Bool">true</Property>
      <Property Name="server.control.propertiesEnabled" Type="Bool">true</Property>
      <Property Name="server.tcp.enabled" Type="Bool">false</Property>
      <Property Name="server.tcp.port" Type="Int">0</Property>
      <Property Name="server.tcp.serviceName" Type="Str">My Computer/VI Server</Property>
      <Property Name="server.tcp.serviceName.default" Type="Str">My Computer/VI Server</Property>
      <Property Name="server.vi.callsEnabled" Type="Bool">true</Property>
      <Property Name="server.vi.propertiesEnabled" Type="Bool">true</Property>
      <Property Name="specify.custom.address" Type="Bool">false</Property>
      <Item Name="B_noConflict.vi" Type="VI" URL="B_noConflict.vi"/>
      <Item Name="Dependencies" Type="Dependencies"/>
      <Item Name="Build Specifications" Type="Build">
         <Item Name="My DLL" Type="DLL">
            <Property Name="App_applicationGUID" Type="Str">{418C6A18-A15F-45DC-97F9-4DCFD1D1EE1B}</Property>
            <Property Name="App_applicationName" Type="Str">C.dll</Property>
            <Property Name="App_companyName" Type="Str">TestStand</Property>
            <Property Name="App_fileType" Type="Int">2</Property>
            <Property Name="App_fileVersion.major" Type="Int">8</Property>
            <Property Name="App_fileVersion.minor" Type="Int">2</Property>
            <Property Name="App_fileVersion.patch" Type="Int">1</Property>
            <Property Name="App_INI_aliasGUID" Type="Str">{9031B965-4201-4641-B7A5-1C408515F909}</Property>
            <Property Name="App_INI_GUID" Type="Str">{96E2F8CC-599A-42F4-BC1A-07A2502E6DDC}</Property>
            <Property Name="App_internalName" Type="Str">My DLL</Property>
            <Property Name="App_legalCopyright" Type="Str">Copyright © 2006 TestStand</Property>
            <Property Name="App_productName" Type="Str">My DLL</Property>
            <Property Name="App_waitDebugging" Type="Bool">true</Property>
            <Property Name="Bld_buildSpecName" Type="Str">My DLL</Property>
            <Property Name="Bld_defaultLanguage" Type="Str">ChineseS</Property>
            <Property Name="Bld_excludeLibraryItems" Type="Bool">true</Property>
            <Property Name="Bld_excludePolymorphicVIs" Type="Bool">true</Property>
            <Property Name="Bld_excludeTypedefs" Type="Bool">true</Property>
            <Property Name="Bld_modifyLibraryFile" Type="Bool">true</Property>
            <Property Name="Destination[0].destName" Type="Str">C.dll</Property>
            <Property Name="Destination[0].path" Type="Path">../foo/internal.llb</Property>
            <Property Name="Destination[0].type" Type="Str">App</Property>
            <Property Name="Destination[1].destName" Type="Str">Support Directory</Property>
            <Property Name="Destination[1].path" Type="Path">/C/Temp/LVCar/DLLHang/foo821/data</Property>
            <Property Name="Destination[1].path.type" Type="Str">&lt;none&gt;</Property>
            <Property Name="Destination[2].destName" Type="Str">Destination Directory</Property>
            <Property Name="Destination[2].path" Type="Path">../foo</Property>
            <Property Name="DestinationCount" Type="Int">3</Property>
            <Property Name="Dll_delayOSMsg" Type="Bool">true</Property>
            <Property Name="Dll_headerGUID" Type="Str">{F658CB05-9AD7-4816-AC96-CA85E1CF3A6F}</Property>
            <Property Name="Dll_libGUID" Type="Str">{BDD1C2B6-CC34-4207-BD83-F04EDE0CB927}</Property>
            <Property Name="Source[0].Container.applyDestination" Type="Bool">true</Property>
            <Property Name="Source[0].Container.applyInclusion" Type="Bool">true</Property>
            <Property Name="Source[0].Container.applyProperties" Type="Bool">true</Property>
            <Property Name="Source[0].itemID" Type="Str">{51DA768A-845F-4221-A901-449C6100062D}</Property>
            <Property Name="Source[0].type" Type="Str">Container</Property>
            <Property Name="Source[1].destinationIndex" Type="Int">0</Property>
            <Property Name="Source[1].ExportedVI.VIProtoInfo[0]VIProtoDir" Type="Int">1</Property>
            <Property Name="Source[1].ExportedVI.VIProtoInfo[0]VIProtoInputIdx" Type="Int">-1</Property>
            <Property Name="Source[1].ExportedVI.VIProtoInfo[0]VIProtoLenInput" Type="Int">-1</Property>
            <Property Name="Source[1].ExportedVI.VIProtoInfo[0]VIProtoLenOutput" Type="Int">-1</Property>
            <Property Name="Source[1].ExportedVI.VIProtoInfo[0]VIProtoName" Type="Str">return value</Property>
            <Property Name="Source[1].ExportedVI.VIProtoInfo[0]VIProtoOutputIdx" Type="Int">-1</Property>
            <Property Name="Source[1].ExportedVI.VIProtoInfo[0]VIProtoPassBy" Type="Int">0</Property>
            <Property Name="Source[1].ExportedVI.VIProtoInfo[1]CallingConv" Type="Int">0</Property>
            <Property Name="Source[1].ExportedVI.VIProtoInfo[1]Name" Type="Str">B_noConflict</Property>
            <Property Name="Source[1].ExportedVI.VIProtoInfo[1]VIProtoDir" Type="Int">0</Property>
            <Property Name="Source[1].ExportedVI.VIProtoInfo[1]VIProtoInputIdx" Type="Int">11</Property>
            <Property Name="Source[1].ExportedVI.VIProtoInfo[1]VIProtoLenInput" Type="Int">-1</Property>
            <Property Name="Source[1].ExportedVI.VIProtoInfo[1]VIProtoLenOutput" Type="Int">-1</Property>
            <Property Name="Source[1].ExportedVI.VIProtoInfo[1]VIProtoName" Type="Str">Numeric</Property>
            <Property Name="Source[1].ExportedVI.VIProtoInfo[1]VIProtoOutputIdx" Type="Int">-1</Property>
            <Property Name="Source[1].ExportedVI.VIProtoInfo[1]VIProtoPassBy" Type="Int">1</Property>
            <Property Name="Source[1].ExportedVI.VIProtoInfoCPTM" Type="Bin">#!#!"1!!!!1!"!!!!!Z!#AF/&gt;7VF=GFD)$)!$%!+"UZV&lt;76S;7-!0!$Q!!Q!!!!!!!!!!1!!!!!!!!!!!!!!!!!!!!)#!!"Y!!!!!!!!$1M!!!!!!!!!!!!!!!!!!!I!!!!!!1!$</Property>
            <Property Name="Source[1].ExportedVI.VIProtoInfoVIProtoItemCount" Type="Int">2</Property>
            <Property Name="Source[1].itemID" Type="Ref">/My Computer/B_noConflict.vi</Property>
            <Property Name="Source[1].properties[0].type" Type="Str">Remove front panel</Property>
            <Property Name="Source[1].properties[0].value" Type="Bool">false</Property>
            <Property Name="Source[1].propertiesCount" Type="Int">1</Property>
            <Property Name="Source[1].sourceInclusion" Type="Str">TopLevel</Property>
            <Property Name="Source[1].type" Type="Str">ExportedVI</Property>
            <Property Name="SourceCount" Type="Int">2</Property>
         </Item>
      </Item>
   </Item>
</Project>
