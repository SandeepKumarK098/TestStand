#include "extcode.h"
#ifdef __cplusplus
extern "C" {
#endif

/*!
 * GetPropertyInt64Value
 */
double __cdecl GetPropertyInt64Value(double Numeric2);

MgErr __cdecl LVDLLStatus(char *errStr, int errStrLen, void *module);

#ifdef __cplusplus
} // extern "C"
#endif

