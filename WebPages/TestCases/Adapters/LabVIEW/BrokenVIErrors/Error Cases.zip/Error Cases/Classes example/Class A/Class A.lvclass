﻿<?xml version='1.0' encoding='UTF-8'?>
<LVClass LVVersion="15008000">
	<Property Name="NI.Lib.FriendGUID" Type="Str">7c496d06-3e7d-4c4e-9307-0721f8232c94</Property>
	<Property Name="NI.Lib.Icon" Type="Bin">&amp;1#!!!!!!!)!"1!&amp;!!!-!%!!!@````]!!!!"!!%!!!(]!!!*Q(C=\&gt;8"=&gt;MQ%!8143;(8.6"2CVM#WJ",7Q,SN&amp;(N&lt;!NK!7VM#WI"&lt;8A0$%94UZ2$P%E"Y.?G@I%A7=11U&gt;M\7P%FXB^VL\`NHV=@X&lt;^39O0^N(_&lt;8NZOEH@@=^_CM?,3)VK63LD-&gt;8LS%=_]J'0@/1N&lt;XH,7^\SFJ?]Z#5P?=F,HP+5JTTF+5`Z&gt;MB$(P+1)YX*RU2DU$(![)Q3YW.YBG&gt;YBM@8'*\B':\B'2Z&gt;9HC':XC':XD=&amp;M-T0--T0-.DK%USWS(H'2\$2`-U4`-U4`/9-JKH!&gt;JE&lt;?!W#%;UC_WE?:KH?:R']T20]T20]\A=T&gt;-]T&gt;-]T?/7&lt;66[UTQ//9^BIHC+JXC+JXA-(=640-640-6DOCC?YCG)-G%:(#(+4;6$_6)]R?.8&amp;%`R&amp;%`R&amp;)^,WR/K&lt;75?GM=BZUG?Z%G?Z%E?1U4S*%`S*%`S'$;3*XG3*XG3RV320-G40!G3*D6^J-(3D;F4#J,(T\:&lt;=HN+P5FS/S,7ZIWV+7.NNFC&lt;+.&lt;GC0819TX-7!]JVO,(7N29CR6L%7,^=&lt;(1M4#R*IFV][.DX(X?V&amp;6&gt;V&amp;G&gt;V&amp;%&gt;V&amp;\N(L@_Z9\X_TVONVN=L^?Y8#ZR0J`D&gt;$L&amp;]8C-Q_%1_`U_&gt;LP&gt;WWPAG_0NB@$TP@4C`%`KH@[8`A@PRPA=PYZLD8Y!#/7SO!!!!!!</Property>
	<Property Name="NI.Lib.SourceVersion" Type="Int">352354304</Property>
	<Property Name="NI.Lib.Version" Type="Str">1.0.0.0</Property>
	<Property Name="NI.LV.All.SourceOnly" Type="Bool">true</Property>
	<Property Name="NI.LVClass.ClassNameVisibleInProbe" Type="Bool">true</Property>
	<Property Name="NI.LVClass.DataValRefToSelfLimitedLibFlag" Type="Bool">true</Property>
	<Property Name="NI.LVClass.FlattenedPrivateDataCTL" Type="Bin">&amp;1#!!!!!!!)!"1!&amp;!!!-!%!!!@````]!!!!"!!%!!"*!5F.31QU+!!.-6E.$4%*76Q!!$CQ!!!15!!!!)!!!$AQ!!!!5!!!!!1^$&lt;'&amp;T=S"",GRW9WRB=X-!!!#1&amp;1#!!!!Q!!!)!!1!!!!!"!!$!$Q!P!!@1)!#!!!!!!%!!1!'`````Q!!!!!!!!!!!!!!!"O,+[=`-L^)BT7FT&gt;LOYEQ!!!!-!!!!%!!!!!"#MY+=&lt;0NZ1*0$+`V&lt;&lt;,_3V"W-W9]!MA4JA!G9\0B#@A!!%!!!!!!!4M"O@25/.5C8H"WJWCJ&gt;4Q%!!!$`````!!!!%$!:'8RJSR.X;P672K!EYR=!!!!%!!!!!!!!!#=!!5R71U-!!!!"!!*735R#!!!!!&amp;"53$!!!!!&amp;!!%!!1!!!!!#!!-!!!!!!A!"!!!!!!!C!!!!((C=9W"D9'JAO-!!R)R!T.4!^!0)`A$C-Q!!;!%).A!!!!!!1Q!!!2BYH'.AQ!4`A1")-4)QM)#Y,'DC9"L'JC&lt;!:3YOO[$CT&amp;!XME*%'9&amp;CT#_!$#;1(+J?&amp;A9E\]!"'R;T!96Q*@!!!!!!$!!"6EF%5Q!!!!!!!Q!!!4Y!!!,-?*Q,9'2A++]Q-XE!J*G"7*3BA3%Z0S76CQ():U#!&amp;5Q-&amp;)%'K(F;;/+'"Q[H!9%?PXQ,G/`2`%&lt;$M`E(5[GARQ[9GP]80*K0;"TW['Y%#2VX3!!L\'9UP/2K?/$`B!NA&lt;5!&amp;`0)/90U.F&gt;9-*?S'"]##RRO`-%+-Q4!1J(Y(30)QKPU?H2=]$DZA]93L^UI79@"B0/$2[=*F=.S&amp;+U!-J*$R&amp;"9$'=+!"CBY&gt;*Z$S/VCB#DI:P09#20T[01)1/&amp;J)0-[Q$Z#&amp;PC!,P!!R4^!SR8C$G-.^\7P\_U#B4NS^$EQ1/*$DY'2!?1Y%*E,F&lt;-"MJGA9D*1-2"\(Z3NA;4H&amp;J*Z-,'Z9$51]^GA9O_A@"$\$Z!/A,+ZA*IG1.H31,9!F+U$:&amp;_!MGWB&lt;'&gt;`&amp;^=,D*D_1U[8!/6@&lt;:9!!!!!!!Q6!)!E!!!%-45O-!!!!!!-&amp;1#!!!!!"$%V,D!!!!!!$"5!A#1!!!1R.3YQ!!!!!!Q6!)!!!!!%-45O-!!!!!!-&amp;1#!*!!!"$%V,D!!!!!!&amp;!%!!!$V6T7#?3;CD#ZT5EY'34G&gt;!!!!$1!!!!!!!!!!!!!!!!!!!!!!!!#!`````Y!!!!'!!!!"A!!!!9!!!!'!!!!"A!!!!9!!!!'!!!!"A!!!!9!!!!'!!!!"A'!!!9'9!!''"A!"G!'!!;!!1!'Q!-!"L!.!!;-/Q!'A^5!"I#L!!;!V1!'A+M!"I$6!!;!KQ!'A.5!"G#O!!99W!!'"O!!"A'!!!@````]!!!1!````````````````````````````````````````````!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!``]!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!$``Q!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!0``!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!``]!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!$``Q!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!0``!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!``]!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!$``Q!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!0``!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!``]!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!$``Q!!!!!!!!!!?(A!!!!!!!!!!!!!!!!!!!!!!!!!!0``!!!!!!!!?+SKK[RY!!!!!!!!!!!!!!!!!!!!!!!!``]!!!!!?+SKI[/DI[OM?!!!!!!!!!!!!!!!!!!!!!$``Q!!?+SKI[/DI[/DI[/LL(A!!!!!!!!!!!!!!!!!!0``!+OKI[/DI[/DI[/DI[/DK[Q!!!!!!!!!!!!!!!!!``]!KKKDI[/DI[/DI[/DI[0_KQ!!!!!!!!!!!!!!!!$``Q#KK[OKI[/DI[/DI[0_`P[K!!!!!!!!!!!!!!!!!0``!+KLK[OLKK/DI[0_`P\_`KI!!!!!!!!!!!!!!!!!``]!KKOLK[OLK[KM`P\_`P\_KA!!!!!!!!!!!!!!!!$``Q#KK[OLK[OLK`\_`P\_`P[K!!!!!!!!!!!!!!!!!0``!+KLK[OLK[OL`P\_`P\_`KI!!!!!!!!!!!!!!!!!``]!KKOLK[OLK[P_`P\_`P\_KA!!!!!!!!!!!!!!!!$``Q#KK[OLK[OLK`\_`P\_`P[K!!!!!!!!!!!!!!!!!0``!+KLK[OLK[OL`P\_`P\_`KI!!!!!!!!!!!!!!!!!``]!K[OLK[OLK[P_`P\_`P[LKQ!!!!!!!!!!!!!!!!$``Q!!J+KLK[OLK`\_`P[LL+1!!!!!!!!!!!!!!!!!!0``!!!!!+3LK[OL`P[LK[1!!!!!!!!!!!!!!!!!!!!!``]!!!!!!!#EK[OLK[-!!!!!!!!!!!!!!!!!!!!!!!$``Q!!!!!!!!!!J+-!!!!!!!!!!!!!!!!!!!!!!!!!!0```````````````````````````````````````````Q!!!!Q!!5:13&amp;!!!!!!!!-!!!*J!!!%YHC=L:4.;R.2&amp;-8P#[/]B"&lt;@J+FWI#'RP-9CS=&lt;0'IS7^H62+57*B3Y+.DDR!VKD46*&gt;N:N"S+*1#'1B&gt;/%G7R&gt;:O*@A:B;[=G("I@E,X"1&amp;/YFX*JG:*.*U9Q+02X*`^^SZZT!!UA]WZGP#NAG%(?&amp;FU93!KB/!?I*#ZR.\#WS:`!%35IA*-X3:(@C;:.S%)670U7OC"$]\V32&amp;XL.$,$X,&amp;'Q7-/'=KF_1\X'$]1`DP(4'[3J$G/W3JG_&amp;2X\283W(AK".7;?=)%UAYK)E;20X-S_S'L&gt;_^3?I9L@UG]#%0LT&amp;D5P9%;5`W3X*(IGD&gt;+=F9-MJK.6K(C3XI:A^RD1S*'[0OT?!#3,TGBNRGQH9$/KE("U2;:;NW3WI(RXB?JY&lt;C,VR.B.XJ%4%H,'R2K/"'*Y&gt;\*E*)7\-5I5?KN`*]!0N)R!A^5?O$`+3:9*&gt;'U1@*J/%J@'?.O'SJPP7G/2MNQBFWQ8*=?'WZ=+M\9*@F"BY.J20N;%_%:Z&lt;,_9,W=VI\EHU]8IGHY__X(S_F3FEIWKGE0H8I*41F;P7UVNC\7S-AA3P9+V\W4GI6KOY!$Q^^![C)^RQ/&gt;F_'N6&gt;O/INX&amp;,V.H=8.S&gt;_0XRK&lt;7]S[8-C#VZ9LW"9Z6$`1$VBP@\`QXJ$[/(NPL$#+HYX"A4P:BPSQILV!"OQ/I#:2G;H/[RN&amp;5&gt;H5&amp;BP#:XVJN6C_^*;K62[/.RZUEWL2%A\L&gt;L8VH(LO$_TY&amp;`KGJQ?@#[[`^-U&amp;SWKH&amp;T!ZF&amp;MRY22-2@]QB;QWR"&gt;I0.M(VX&amp;N^&amp;ZOE_0[N`=]PKC?_8P)H4M,W896IY!!!!!!!!%!!!!)!!!!!1!!!!!!!!!$!!"1E2)5!!!!!!!!Q!!!')!!!"S?*RD9'$)%Z"A_M&gt;1^Z?"3?!LE#(^FY&amp;:U)`R.Q-$JZ`!93$.+#!*&amp;*&lt;^S]!OK!U7VD[CS]%!";JMD"S3()=&amp;/=!S(#U;$0```_@Y?O1;8-52(TB4::9]BQ1!&amp;'):!!!!!!!!"!!!!!=!!!'M!!!!"A!!!#&amp;@&lt;GF@4'&amp;T&gt;%NO&lt;X&gt;O4X&gt;O;7ZH4&amp;:$&lt;'&amp;T=U.M&gt;8.U:8)!!!!K&amp;1#!!!!!!!%!#!!Q`````Q!"!!!!!!!/!!!!!1!'!&amp;!!!!!"!!!!!!!!!!!!'ER71WRB=X.1=GFW982F2'&amp;U962B9E^S:'6S!!!!*25!A!!!!!!#!!5!"Q!!$!"!!!(`````!!!!!1!"!!!!!!!!!!!!!!!&lt;4&amp;:$&lt;'&amp;T=V"S;8:B&gt;'6%982B6'FN:8.U97VQ!!!!'25!A!!!!!!"!!5!"Q!!!1!!T-L"JQ!!!!!!!!!G4&amp;:$&lt;'&amp;T=V"S;8:B&gt;'6%982B4'&amp;T&gt;%&amp;Q='RJ:725;7VF=X2B&lt;8!!!!!:&amp;1#!!!!!!!%!"1!(!!!"!!$-SM'H!!!!!!!!!"J-6E.M98.T5(*J&gt;G&amp;U:52B&gt;'&amp;5?8"F2'6T9Q!!!#I6!)!!!!!!!1!)!$$`````!!%!!!!!!!Y!!!!"!!9!5!!!!!%!!!!!!!!!!!!?4&amp;:$&lt;'&amp;T=V"S;8:B&gt;'6%982B2':M&gt;%2B&gt;'&amp;4;8JF!!!!'25!A!!!!!!"!!5!!Q!!!1!!!!!!!!!!!!!!!!!%!!)!#!!!!!1!!!"!!!!!+!!!!!)!!!1!!!!!!1!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!$=!!!"4XC=D:!^&lt;M*!&amp;)1`?QE`&gt;A+%.$2)7V#E3J-,/%*+29&amp;SAFD92J&amp;7-M),IMRN=AZ;F-PE"BE&lt;5!K;;+3H.\0PT?QO]-#=H_`DY1M)"T/86J6^?8+\:&gt;X&amp;&amp;\\UDM&gt;E!:/:WV9_X^CSM-W)87]_&gt;KH0&lt;:&lt;[F"O"C!T-G%$%H#H0;HN*"V/Y&amp;&gt;XEUZ2P`C4E:=&amp;1XE&lt;D&lt;4JGGR6%&gt;:&lt;R_UT&lt;#U+[^*D_+T_EM6%*U.K\IFO]SM2SSZX%'HW&amp;82#==;X]H1Q;H"Y3-*1DOJ!_4&amp;V%T$UDV@A8RN=S9A!!!'5!!1!#!!-!"!!!!%A!$Q1!!!!!$Q$9!.5!!!"2!!]%!!!!!!]!W!$6!!!!7A!0"!!!!!!0!.A!V1!!!'/!!)1!A!!!$Q$9!.5)5W6H&lt;W5A65E)5W6H&lt;W5A65E)5W6H&lt;W5A65E"-!!!!&amp;*45E-.#A!$4&amp;:$1UR#6F=!!!YM!!!%&amp;!!!!#!!!!Y-!!!!!!!!!!!!!!!A!!!!.!!!"!A!!!!&lt;4%F#4A!!!!!!!!&amp;54&amp;:45A!!!!!!!!&amp;I5F242Q!!!!!!!!&amp;]1U.46!!!!!!!!!'14%FW;1!!!!!!!!'E1U^/5!!!!!!!!!'Y6%UY-!!!!!!!!!(-2%:%5Q!!!!!!!!(A4%FE=Q!!!!!!!!(U6EF$2!!!!!!!!!))&gt;G6S=Q!!!!1!!!)=5U.45A!!!!!!!!+!2U.15A!!!!!!!!+535.04A!!!!!!!!+I;7.M/!!!!!!!!!+]4%FG=!!!!!!!!!,12F")9A!!!!!!!!,E2F"421!!!!!!!!,Y6F"%5!!!!!!!!!--4%FC:!!!!!!!!!-A1E2)9A!!!!!!!!-U1E2421!!!!!!!!.)6EF55Q!!!!!!!!.=2&amp;2)5!!!!!!!!!.Q466*2!!!!!!!!!/%3%F46!!!!!!!!!/96E.55!!!!!!!!!/M2F2"1A!!!!!!!!0!!!!!!0````]!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!9!!!!!!!!!!$`````!!!!!!!!!+Q!!!!!!!!!!0````]!!!!!!!!!Q!!!!!!!!!!!`````Q!!!!!!!!$)!!!!!!!!!!$`````!!!!!!!!!01!!!!!!!!!!0````]!!!!!!!!!`!!!!!!!!!!!`````Q!!!!!!!!%E!!!!!!!!!!$`````!!!!!!!!!7Q!!!!!!!!!!0````]!!!!!!!!"@!!!!!!!!!!%`````Q!!!!!!!!,!!!!!!!!!!!@`````!!!!!!!!!N!!!!!!!!!!#0````]!!!!!!!!#Y!!!!!!!!!!*`````Q!!!!!!!!,Q!!!!!!!!!!L`````!!!!!!!!!Q!!!!!!!!!!!0````]!!!!!!!!$%!!!!!!!!!!!`````Q!!!!!!!!-I!!!!!!!!!!$`````!!!!!!!!!TQ!!!!!!!!!!0````]!!!!!!!!$Q!!!!!!!!!!!`````Q!!!!!!!!@%!!!!!!!!!!$`````!!!!!!!!"^1!!!!!!!!!!0````]!!!!!!!!+2!!!!!!!!!!!`````Q!!!!!!!!J-!!!!!!!!!!$`````!!!!!!!!#F1!!!!!!!!!!0````]!!!!!!!!+:!!!!!!!!!!!`````Q!!!!!!!!L-!!!!!!!!!!$`````!!!!!!!!#N1!!!!!!!!!!0````]!!!!!!!!-B!!!!!!!!!!!`````Q!!!!!!!!S-!!!!!!!!!!$`````!!!!!!!!$*1!!!!!!!!!!0````]!!!!!!!!-Q!!!!!!!!!#!`````Q!!!!!!!!WA!!!!!!N$&lt;'&amp;T=S"",G.U&lt;!!!!!!</Property>
	<Property Name="NI.LVClass.Geneology" Type="Xml"><String>

<Name></Name>

<Val>!!!!!1^$&lt;'&amp;T=S"",GRW9WRB=X.16%AQ!!!!!!!!!!!!!!!"!!%!!!!!!!!!!!!!!1!'!&amp;!!!!!"!!!!!!!!!!!!!!%/4'&amp;C6EF&amp;6S"09GJF9X1!5&amp;2)-!!!!!!!!!!!!")!A!1!!!!!!!!!!!!!</Val>

</String>

</Property>
	<Property Name="NI.LVClass.IsTransferClass" Type="Bool">false</Property>
	<Item Name="Class A.ctl" Type="Class Private Data" URL="Class A.ctl">
		<Property Name="NI.LibItem.Scope" Type="Int">2</Property>
	</Item>
	<Item Name="Calling VI in Class A.vi" Type="VI" URL="../Calling VI in Class A.vi">
		<Property Name="NI.ClassItem.ConnectorPane" Type="Bin">&amp;1#!!!!!!!)!"1!&amp;!!!-!%!!!@````]!!!!"!!%!!!"A!!!!!A!%!!!!6!$Q!!Q!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!#!!"Y!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1!"!!!!!!</Property>
		<Property Name="NI.ClassItem.ExecutionSystem" Type="Int">-1</Property>
		<Property Name="NI.ClassItem.Flags" Type="Int">0</Property>
		<Property Name="NI.ClassItem.IsStaticMethod" Type="Bool">true</Property>
		<Property Name="NI.ClassItem.MethodScope" Type="UInt">1</Property>
		<Property Name="NI.ClassItem.Priority" Type="Int">1</Property>
		<Property Name="NI.ClassItem.State" Type="Int">1082130944</Property>
	</Item>
	<Item Name="Community Member of Class A.vi" Type="VI" URL="../Community Member of Class A.vi">
		<Property Name="NI.ClassItem.ConnectorPane" Type="Bin">&amp;1#!!!!!!!)!"1!&amp;!!!-!%!!!@````]!!!!"!!%!!!"A!!!!!A!%!!!!6!$Q!!Q!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"Y!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1!"!!!!!!</Property>
		<Property Name="NI.ClassItem.ExecutionSystem" Type="Int">-1</Property>
		<Property Name="NI.ClassItem.Flags" Type="Int">0</Property>
		<Property Name="NI.ClassItem.IsStaticMethod" Type="Bool">true</Property>
		<Property Name="NI.ClassItem.MethodScope" Type="UInt">4</Property>
		<Property Name="NI.ClassItem.Priority" Type="Int">1</Property>
		<Property Name="NI.ClassItem.State" Type="Int">1082130944</Property>
		<Property Name="NI.LibItem.Scope" Type="Int">4</Property>
	</Item>
	<Item Name="Private Member of Class A.vi" Type="VI" URL="../Private Member of Class A.vi">
		<Property Name="NI.ClassItem.ConnectorPane" Type="Bin">&amp;1#!!!!!!!)!"1!&amp;!!!-!%!!!@````]!!!!"!!%!!!"A!!!!!A!%!!!!6!$Q!!Q!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"Y!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1!"!!!!!!</Property>
		<Property Name="NI.ClassItem.ExecutionSystem" Type="Int">-1</Property>
		<Property Name="NI.ClassItem.Flags" Type="Int">0</Property>
		<Property Name="NI.ClassItem.IsStaticMethod" Type="Bool">true</Property>
		<Property Name="NI.ClassItem.MethodScope" Type="UInt">2</Property>
		<Property Name="NI.ClassItem.Priority" Type="Int">1</Property>
		<Property Name="NI.ClassItem.State" Type="Int">1082130944</Property>
		<Property Name="NI.LibItem.Scope" Type="Int">2</Property>
	</Item>
	<Item Name="Protected Member of Class A.vi" Type="VI" URL="../Protected Member of Class A.vi">
		<Property Name="NI.ClassItem.ConnectorPane" Type="Bin">&amp;1#!!!!!!!)!"1!&amp;!!!-!%!!!@````]!!!!"!!%!!!"A!!!!!A!%!!!!6!$Q!!Q!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"Y!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1!"!!!!!!</Property>
		<Property Name="NI.ClassItem.ExecutionSystem" Type="Int">-1</Property>
		<Property Name="NI.ClassItem.Flags" Type="Int">0</Property>
		<Property Name="NI.ClassItem.IsStaticMethod" Type="Bool">true</Property>
		<Property Name="NI.ClassItem.MethodScope" Type="UInt">3</Property>
		<Property Name="NI.ClassItem.Priority" Type="Int">1</Property>
		<Property Name="NI.ClassItem.State" Type="Int">1074266624</Property>
		<Property Name="NI.LibItem.Scope" Type="Int">3</Property>
	</Item>
	<Item Name="Public Member of Class A.vi" Type="VI" URL="../Public Member of Class A.vi">
		<Property Name="NI.ClassItem.ConnectorPane" Type="Bin">&amp;1#!!!!!!!)!"1!&amp;!!!-!%!!!@````]!!!!"!!%!!!"A!!!!!A!%!!!!6!$Q!!Q!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"Y!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1!"!!!!!!</Property>
		<Property Name="NI.ClassItem.ExecutionSystem" Type="Int">-1</Property>
		<Property Name="NI.ClassItem.Flags" Type="Int">0</Property>
		<Property Name="NI.ClassItem.IsStaticMethod" Type="Bool">true</Property>
		<Property Name="NI.ClassItem.MethodScope" Type="UInt">1</Property>
		<Property Name="NI.ClassItem.Priority" Type="Int">1</Property>
		<Property Name="NI.ClassItem.State" Type="Int">1074278912</Property>
	</Item>
</LVClass>
