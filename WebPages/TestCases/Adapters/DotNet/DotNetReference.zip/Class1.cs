using System;
using System.Collections.Generic;
using System.Text;
using NationalInstruments.TestStand.Interop.API;
using System.Windows.Forms;

namespace DotNetReference
{
	public class ReferenceTest
	{
		public void saveObject(SequenceContext seqContext, String str)
		{
			ClassToTest x = new ClassToTest();
			x.Str = "Test string using SetValVariant = " + str;
			seqContext.Locals.SetValInterface("variant", PropertyOptions.PropOption_InsertIfMissing, null);
			seqContext.Locals.SetValVariant("variant", PropertyOptions.PropOption_NoOptions, x);


			ClassToTest y = new ClassToTest();
			y.Str = "Test string using SetValInterface = " + str;

			seqContext.Locals.SetValInterface("interface", PropertyOptions.PropOption_InsertIfMissing, y);

			x = null;
			y = null;
			GC.Collect();
			GC.Collect();
			GC.Collect();
			GC.Collect();
			GC.Collect();
			GC.Collect();
		}

		public void retrieveObject(SequenceContext seqContext)
		{
			ClassToTest x = seqContext.Locals.GetValVariant("variant", PropertyOptions.PropOption_NoOptions) as ClassToTest;
			x.test();


			ClassToTest y = seqContext.Locals.GetValInterface("interface", PropertyOptions.PropOption_NoOptions) as ClassToTest;
			y.test();
		}

		public void test(ClassToTest x)
		{
			x.test();
		}
	}

	public class ClassToTest
	{
		private string mStr;

		public string Str
		{
			get { return mStr; }
			set { mStr = value; }
		}

		public void test()
		{
			MessageBox.Show(this.mStr);
		}

		~ClassToTest()
		{
			MessageBox.Show("finalizer");
		}
	}
}
