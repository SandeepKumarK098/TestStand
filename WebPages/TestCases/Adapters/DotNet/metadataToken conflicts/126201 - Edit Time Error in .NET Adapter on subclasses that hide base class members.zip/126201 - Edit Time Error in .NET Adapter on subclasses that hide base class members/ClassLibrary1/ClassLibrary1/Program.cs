using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibrary1
{

	public class a
	{
		private int _abc;

		public int Def
		{
			private get
			{
				return _abc;
			}
			set
			{
				_abc = value;
			}
		}

		public int Abc
		{
			get
			{
				return _abc;
			}
			set
			{
				_abc = value;
			}
		}

		public Int32 get_temp()
		{
			return 0;
		}

		public void set_temp(Int32 a)
		{

		}
	}
	public class b : a
	{
		private int _abc;

		public new int Abc
		{
			get
			{
				return _abc;
			}
			set
			{
				_abc = value;
			}
		}
	}
}
